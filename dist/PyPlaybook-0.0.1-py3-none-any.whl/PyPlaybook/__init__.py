# -*- coding: utf-8 -*-
'''
Author: David J. Morfe
Application Name: gomaps
Functionality Purpose: Acquire google maps data to utilize for web scraping
Version: Beta
'''

name = "PyPlaybook"
from .PyPlaybook import *
