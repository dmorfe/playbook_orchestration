# -*- coding: utf-8 -*-
'''
Author: David Morfe
Application Name: PyPlaybook
Functionality Purpose: Python tool to automate connecting to network devices and retrieve information and/or make configration changes
Version: Beta
'''

name = "PyPlaybook"
from .PyPlaybook import *
